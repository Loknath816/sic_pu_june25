# main.py

from modules.analyzer import DeliveryDataLoader
from modules.visualizer import (
    plot_sector_distribution_pie,
    plot_avg_cdr_by_sector,
    plot_water_quality_vs_cdr,
    plot_top_states_by_cdr
)


def main():
    """
    CLI interface to choose and run visual analysis.
    """
    # To make sure these paths are correct
    loader = DeliveryDataLoader(
        'data/Box1.csv',
        'data/Analysis_Code.xlsx'  # Optional
    )

    df = loader.raw_data

    while True:
        print("\nSelect an Analysis:")
        print("1. Delivery Distribution by Sector")
        print("2. Average C-Section Rate by Sector")
        print("3. Water Quality vs C-section delivery rate")
        print("4. Top 5 States by  C-section delivery rate")
        print("5. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            plot_sector_distribution_pie(df)
        elif choice == '2':
            plot_avg_cdr_by_sector(df)
        elif choice == '3':
            plot_water_quality_vs_cdr(df)
        elif choice == '4':
            plot_top_states_by_cdr(df, top_n=5)
        elif choice == '5':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
