# modules/visualizer.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns



def plot_sector_distribution_pie(df):
    
    """
    Displays a pie chart showing the percentage distribution of records across sectors.
    """
    if df.empty or 'Sector' not in df.columns:
        print("Missing 'Sector' column in data.")
        return

    sector_counts = df['Sector'].value_counts()

    # Sort sectors for consistent pie layout
    sector_counts = sector_counts.sort_values(ascending=False)

    # Pie chart with percentages and count labels
    plt.figure(figsize=(7, 7))
    wedges, texts, autotexts = plt.pie(
        sector_counts,
        labels=sector_counts.index,
        autopct=lambda pct: f'{pct:.1f}%\n({int(pct * sector_counts.sum() / 100)})',
        startangle=140,
        colors=plt.cm.Pastel1.colors,
        textprops={'fontsize': 10}
    )

    plt.title('Delivery Distribution by Sector', fontsize=14)
    plt.axis('equal')  # Make it a circle
    plt.tight_layout()
    plt.show()


def plot_avg_cdr_by_sector(df):
    """
    Plots average C-Section Rate by sector.
    """
    if df.empty or 'CDR' not in df.columns or 'Sector' not in df.columns:
        print("Missing required columns in data.")
        return

    df['CDR'] = pd.to_numeric(df['CDR'], errors='coerce')
    df_clean = df.dropna(subset=['CDR'])

    avg_cdr = df_clean.groupby('Sector')['CDR'].mean().round(2).sort_values(ascending=False)
    avg_cdr.plot(kind='bar', color='coral', title='Avg C-Section Rate by Sector')
    plt.ylabel('Average C-Section Rate (%)')
    plt.xlabel('Sector')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot_water_quality_vs_cdr(df):
    """
    Enhanced plot showing the relationship between Water Quality and CDR.
    Uses boxplot + stripplot with mean annotations.
    """
    if 'WQ' not in df.columns or 'CDR' not in df.columns:
        print("Missing 'WQ' or 'CDR' column in data.")
        return

    df['CDR'] = pd.to_numeric(df['CDR'], errors='coerce')
    df = df.dropna(subset=['WQ', 'CDR'])

    wq_order = ['Poorest', 'Poorer', 'Middle', 'Richer', 'Richest']
    df['WQ'] = pd.Categorical(df['WQ'], categories=wq_order, ordered=True)

    plt.figure(figsize=(8, 5))
    sns.boxplot(x='WQ', y='CDR', data=df, order=wq_order, palette='Pastel1', hue='WQ', legend=False)
    sns.stripplot(x='WQ', y='CDR', data=df, order=wq_order, color='black', size=3, jitter=0.2, alpha=0.6)

    mean_values = df.groupby('WQ', observed=True)['CDR'].mean()
    for i, wq in enumerate(wq_order):
        if wq in mean_values:
            plt.text(i, mean_values[wq] + 1, f'{mean_values[wq]:.1f}%', 
                     ha='center', va='bottom', fontsize=9, color='red')

    plt.title('Water Quality vs CDR (C-Section Delivery Rate)')
    plt.xlabel('Water Quality Group')
    plt.ylabel('CDR (%)')
    plt.tight_layout()
    plt.show()


def plot_top_states_by_cdr(df, top_n=5):
    """
    Plots top N states by average C-Section Rate.

    Args:
        df (DataFrame): Dataset with 'State' and 'CDR'
        top_n (int): Number of top states to show
    """
    if df.empty or 'State' not in df.columns or 'CDR' not in df.columns:
        print("Missing required columns in data.")
        return

    df['CDR'] = pd.to_numeric(df['CDR'], errors='coerce')
    df_clean = df.dropna(subset=['CDR'])

    top_states = df_clean.groupby('State')['CDR'].mean().round(2).sort_values(ascending=False).head(top_n)
    top_states.plot(kind='barh', color='green', title=f'Top {top_n} States by Avg C-Section Rate')
    plt.xlabel('C-Section Rate')
    plt.ylabel('State')
    plt.gca().invert_yaxis()
    plt.tight_layout()
    plt.show()
