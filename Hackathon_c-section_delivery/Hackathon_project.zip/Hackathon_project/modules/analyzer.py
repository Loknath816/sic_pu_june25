# modules/analyzer.py

import pandas as pd


class DeliveryDataLoader:
    """
    Loads and preprocesses datasets required for delivery analysis.
    """

    def __init__(self, box1_path: str, excel_path: str = None):
        """
        Initializes the data loader with file paths.

        Args:
            box1_path (str): Path to Box1.csv
            excel_path (str, optional): Path to Excel file for extra data
        """
        self.box1_path = box1_path
        self.excel_path = excel_path
        self.raw_data = pd.read_csv(self.box1_path)
        self.raw_data.columns = [col.strip() for col in self.raw_data.columns]  # Clean headers
        print(f"[INFO] Loaded {len(self.raw_data)} records from {self.box1_path}")

        # Load additional Excel data if provided
        if self.excel_path:
            self._load_excel_data()

        # Add BMI categories if BMI column exists
        if 'BMI' in self.raw_data.columns:
            self._categorize_bmi()

    def _load_excel_data(self):
        """
        Loads sheets from Excel file if path is provided.
        """
        try:
            excel_sheets = pd.read_excel(self.excel_path, sheet_name=None)
            self.statewise_urban_rural = excel_sheets.get('Statewise_Urban_Rural', pd.DataFrame())
            self.csection_factors = excel_sheets.get('CSection_Factors', pd.DataFrame())
            print("[INFO] Excel data loaded successfully.")
        except Exception as e:
            print(f"[ERROR] Failed to load Excel file: {e}")

    def _categorize_bmi(self):
        """
        Categorizes BMI values into standard groups.
        """
        self.raw_data['BMI_Category'] = pd.cut(
            self.raw_data['BMI'],
            bins=[0, 18.5, 24.9, 29.9, 100],
            labels=["Underweight", "Normal", "Overweight", "Obese"]
        )
